package com._520it.crm.util;

import java.util.ArrayList;
import java.util.List;

public class CommonUtil {
    // 存放当前系统所有权限资源（即需要进行权限判断的url地址）
    public static final List<String> ALL_PERMISSIONS = new ArrayList<>();

}
