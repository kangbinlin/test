package com._520it.crm.mapper;

import com._520it.crm.domain.Menu;
import java.util.List;

public interface MenuMapper {

    List<Menu> queryForMenu();

//    List<Menu> queryByParentId();
}